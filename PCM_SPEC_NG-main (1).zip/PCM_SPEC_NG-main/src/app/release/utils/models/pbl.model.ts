export class AddPblModel {
    release_type : string = "new_pbl";
    module_type : string = "";
    current_pbl : string = "";
    new_pbl : string = "";
}
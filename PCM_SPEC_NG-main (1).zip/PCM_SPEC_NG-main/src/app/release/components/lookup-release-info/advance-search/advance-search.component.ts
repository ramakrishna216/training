import { Component } from '@angular/core';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrl: './advance-search.component.scss'
})
export class AdvanceSearchComponent {

}

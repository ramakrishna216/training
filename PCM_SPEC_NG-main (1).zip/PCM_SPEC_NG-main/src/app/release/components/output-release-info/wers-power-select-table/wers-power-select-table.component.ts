import { Component } from '@angular/core';

@Component({
  selector: 'app-wers-power-select-table',
  templateUrl: './wers-power-select-table.component.html',
  styleUrl: './wers-power-select-table.component.scss'
})
export class WersPowerSelectTableComponent {

}
